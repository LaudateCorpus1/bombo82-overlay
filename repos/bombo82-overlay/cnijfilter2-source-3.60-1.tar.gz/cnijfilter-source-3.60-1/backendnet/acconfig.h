#undef PROG_PATH
#undef BJLIB_PATH
