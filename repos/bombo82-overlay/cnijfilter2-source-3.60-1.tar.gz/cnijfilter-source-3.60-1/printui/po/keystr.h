/* LUM_VERSION_PRODUCT_NAME */
gchar *s = N_("Canon Inkjet Printer Driver");
/* LUM_VERSION_VER_STR */
gchar *s = N_("Version %s");
/* LUM_VERSION_COPYRIGHT1_STR */
gchar *s = N_("Copyright CANON INC. %s-%s");
/* LUM_VERSION_COPYRIGHT2_STR */
gchar *s = N_("All Rights Reserved.");
/* LUM_LID_CAPTION */
gchar *s = N_("Canon XXXXXX");
/* model_BJF850 */
gchar *s = N_("BJF850");
/* model_BJF860 */
gchar *s = N_("BJF860");
/* model_BJF870 */
gchar *s = N_("BJF870");
/* model_BJF360 */
gchar *s = N_("BJF360");
/* model_BJS600 */
gchar *s = N_("BJS600");
/* model_BJS630 */
gchar *s = N_("BJS630");
/* model_BJS6300 */
gchar *s = N_("BJS6300");
/* model_BJF900 */
gchar *s = N_("BJF900");
/* model_BJF9000 */
gchar *s = N_("BJF9000");
/* model_BJS500 */
gchar *s = N_("BJS500");
/* model_BJS300 */
gchar *s = N_("BJS300");
/* model_PIXUS550i */
gchar *s = N_("PIXUS 550i");
/* model_PIXUS850i */
gchar *s = N_("PIXUS 850i");
/* model_PIXUS950i */
gchar *s = N_("PIXUS 950i");
/* model_i250 */
gchar *s = N_("i250");
/* model_i255 */
gchar *s = N_("i255");
/* model_PIXUS560i */
gchar *s = N_("PIXUS 560i");
/* model_PIXUS860i */
gchar *s = N_("PIXUS 860i");
/* model_PIXUS990i */
gchar *s = N_("PIXUS 990i");
/* model_PIXUSiP3100 */
gchar *s = N_("PIXUS iP3100");
/* model_PIXUSiP4100 */
gchar *s = N_("PIXUS iP4100");
/* model_PIXUSiP8600 */
gchar *s = N_("PIXUS iP8600");
/* model_PIXMAiP1000 */
gchar *s = N_("PIXMA iP1000");
/* model_PIXMAiP1500 */
gchar *s = N_("PIXMA iP1500");
/* model_iP2200 */
gchar *s = N_("iP2200");
/* model_iP4200 */
gchar *s = N_("iP4200");
/* model_iP6600d */
gchar *s = N_("iP6600D");
/* model_iP7500 */
gchar *s = N_("iP7500");
/* model_MP500 */
gchar *s = N_("MP500");
/* model_iP3300 */
gchar *s = N_("iP3300");
/* model_MP510 */
gchar *s = N_("MP510");
/* model_iP4300 */
gchar *s = N_("iP4300");
/* model_MP600 */
gchar *s = N_("MP600");
/* model_MP160 */
gchar *s = N_("MP160");
/* model_iP90 */
gchar *s = N_("iP90");
/* model_iP2500 */
gchar *s = N_("iP2500 series");
/* model_iP1800 */
gchar *s = N_("iP1800 series");
/* model_MP140 */
gchar *s = N_("MP140 series");
/* model_MP210 */
gchar *s = N_("MP210 series");
/* model_iP3500 */
gchar *s = N_("iP3500 series");
/* model_iP4500 */
gchar *s = N_("iP4500 series");
/* model_MP610 */
gchar *s = N_("MP610 series");
/* model_MP520 */
gchar *s = N_("MP520 series");
/* model_IP100 */
gchar *s = N_("iP100 series");
/* model_IP2600 */
gchar *s = N_("iP2600 series");
/* model_IP3600 */
gchar *s = N_("iP3600 series");
/* model_IP4600 */
gchar *s = N_("iP4600 series");
/* model_MP630 */
gchar *s = N_("MP630 series");
/* model_MP540 */
gchar *s = N_("MP540 series");
/* model_MP240 */
gchar *s = N_("MP240 series");
/* model_MP190 */
gchar *s = N_("MP190 series");
/* model_IP1900 */
gchar *s = N_("iP1900 series");
/* model_MX860 */
gchar *s = N_("MX860 series");
/* model_MX320 */
gchar *s = N_("MX320 series");
/* model_MX330 */
gchar *s = N_("MX330 series");
/* model_MP250 */
gchar *s = N_("MP250 series");
/* model_MP270 */
gchar *s = N_("MP270 series");
/* model_MP490 */
gchar *s = N_("MP490 series");
/* model_MP550 */
gchar *s = N_("MP550 series");
/* model_MP560 */
gchar *s = N_("MP560 series");
/* model_IP4700 */
gchar *s = N_("iP4700 series");
/* model_MP640 */
gchar *s = N_("MP640 series");
/* model_IP2700 */
gchar *s = N_("iP2700 series");
/* model_MX340 */
gchar *s = N_("MX340 series");
/* model_MX350 */
gchar *s = N_("MX350 series");
/* model_MX870 */
gchar *s = N_("MX870 series");
/* model_MP495 */
gchar *s = N_("MP495 series");
/* model_MP280 */
gchar *s = N_("MP280 series");
/* model_MG5100 */
gchar *s = N_("MG5100 series");
/* model_MG5200 */
gchar *s = N_("MG5200 series");
/* model_IP4800 */
gchar *s = N_("iP4800 series");
/* model_MG6100 */
gchar *s = N_("MG6100 series");
/* model_MG8100 */
gchar *s = N_("MG8100 series");
/* model_MX360 */
gchar *s = N_("MX360 series");
/* model_MX410 */
gchar *s = N_("MX410 series");
/* model_MX420 */
gchar *s = N_("MX420 series");
/* model_MX880 */
gchar *s = N_("MX880 series");
/* model_IX6500 */
gchar *s = N_("iX6500 series");
/* model_MG2100 */
gchar *s = N_("MG2100 series");
/* model_MG3100 */
gchar *s = N_("MG3100 series");
/* model_MG4100 */
gchar *s = N_("MG4100 series");
/* model_MG5300 */
gchar *s = N_("MG5300 series");
/* model_MG6200 */
gchar *s = N_("MG6200 series");
/* model_MG8200 */
gchar *s = N_("MG8200 series");
/* model_IP4900 */
gchar *s = N_("iP4900 series");
/* model_E500 */
gchar *s = N_("E500 series");
/* print_color_message */
gchar *s = N_("Color");
/* print_mono_message */
gchar *s = N_("Grayscale");
/* color_correct_photo */
gchar *s = N_("Photo");
/* color_correct_graphics */
gchar *s = N_("Graphic");
/* color_correct_photo2 */
gchar *s = N_("Standard");
/* color_correct_natural */
gchar *s = N_("Linear Tone");
/* mediasize_recommend_message1_1 */
gchar *s = N_("Changing %s to %s is recommended.");
/* mediasize_recommend_message1_2 */
gchar *s = N_("Click Change to use the new combination, Ignore to use the current \n"
              "combination, or Back to Setup to select a different combination.");
/* mediasize_recommend_message2_1 */
gchar *s = N_("Changing %s setting is recommended.");
/* mediasize_recommend_message2_2 */
gchar *s = N_("Use the selector below to choose a suitable setting and click Change to use \n"
              "the new combination.");
/* mediasize_recommend_message2_3 */
gchar *s = N_("Click Ignore to use the current combination or Back to Setup to select a \n"
              "different combination.");
/* mediasize_illegal_select_message2_1 */
gchar *s = N_("Changing %s setting is recommended.  ");
/* mediasize_illegal_select_message2_2 */
gchar *s = N_("Use the selector below to choose a suitable setting and click Change to use \n"
              "the new combination. Click Back to Setup to select a different combination.");
/* lever_position_label */
gchar *s = N_("Paper Thickness Lever Position:");
/* lever_position_label_2007 */
gchar *s = N_("Paper Thickness Lever Position: ");
/* move_lever_position_alert */
gchar *s = N_("Move the paper thickness lever %s.");
/* move_lever_position_alert_2007 */
gchar *s = N_("Move the paper thickness lever %s. ");
/* mediasize_change_media */
gchar *s = N_("Media Type");
/* mediasize_change_size */
gchar *s = N_("Page Size");
/* mediatype_dialog_message */
gchar *s = N_("Media Type: %s cannot be used with the selected BJ Cartridge.\n"
              "Select the type of media you wish to use.");
/* media_plain */
gchar *s = N_("Plain Paper");
/* media_ohp */
gchar *s = N_("Transparencies");
/* media_bpf */
gchar *s = N_("Back Print Film");
/* media_bjcloth */
gchar *s = N_("Fabric Sheet");
/* media_higlossfilm */
gchar *s = N_("High Gloss Film");
/* media_postcard */
gchar *s = N_("Hagaki");
/* media_envelope */
gchar *s = N_("Envelope");
/* media_glossy_postcard */
gchar *s = N_("Glossy Postcard");
/* media_hires */
gchar *s = N_("High Resolution Paper");
/* media_tshirt */
gchar *s = N_("T-Shirt Transfers");
/* media_thick */
gchar *s = N_("Thick Paper");
/* media_higloss_photo_film */
gchar *s = N_("High Gloss Photo Film");
/* media_glossy_photo */
gchar *s = N_("Glossy Photo Paper");
/* media_glossy_photocard */
gchar *s = N_("Glossy Photo Cards");
/* media_pro_photo */
gchar *s = N_("Photo Paper Pro");
/* media_inkjet_postcard */
gchar *s = N_("Ink Jet Hagaki");
/* media_matte_photo */
gchar *s = N_("Matte Photo Paper");
/* media_photo_plus_glossy */
gchar *s = N_("Photo Paper Plus Glossy");
/* media_other */
gchar *s = N_("Other Paper");
/* media_other_photo */
gchar *s = N_("Other Photo Paper");
/* media_duplex_glossy */
gchar *s = N_("Photo Paper Plus Double Sided");
/* media_fine_art_paper */
gchar *s = N_("Fine Art \"Photo Rag\"");
/* media_other_fine_art_paper */
gchar *s = N_("Other Fine Art Paper");
/* media_photo_paper_plus_glossy_ii */
gchar *s = N_("Photo Paper Plus Glossy II");
/* media_photo_paper_plus_semi_gloss */
gchar *s = N_("Photo Paper Plus Semi-gloss");
/* media_photo_paper_pro_platinum */
gchar *s = N_("Photo Paper Pro Platinum");
/* media_photo_paper_pro_ii */
gchar *s = N_("Photo Paper Pro II");
/* media_contents_glossy */
gchar *s = N_("Hagaki K");
/* media_contents_prophoto */
gchar *s = N_("Hagaki P");
/* media_address_postcard */
gchar *s = N_("Hagaki A");
/* supply_manual */
gchar *s = N_("Manual Feed");
/* supply_asf */
gchar *s = N_("Auto Sheet Feeder");
/* supply_asf_reartray */
gchar *s = N_("Rear Tray");
/* supply_asf2 */
gchar *s = N_("Auto Feeder2");
/* supply_cassette */
gchar *s = N_("Standard Cassette");
/* supply_cassette2 */
gchar *s = N_("Optional Cassette");
/* supply_consecutive */
gchar *s = N_("Auto Select");
/* supply_consecutive2 */
gchar *s = N_("Consecutive paper feeding");
/* supply_tractor */
gchar *s = N_("Tractor Feeder");
/* supply_cassette_02 */
gchar *s = N_("Cassette");
/* supply_printer_sw_select */
gchar *s = N_("Paper Feed Switch");
/* supply_cassette_04 */
gchar *s = N_("Front Feeder");
/* supply_cassette_04_fronttray */
gchar *s = N_("Front Tray");
/* supply_front_for_plain */
gchar *s = N_("Front for Plain Paper");
/* supply_front_for_plain_maetray */
gchar *s = N_("Front for Plain Paper ");
/* supply_auto_continuous_feed */
gchar *s = N_("Continuous Autofeed");
/* supply_auto_select */
gchar *s = N_("Automatically Select");
/* supply_change_mes */
gchar *s = N_("The selected paper size cannot be used in the current Paper Source setting.\n"
              "Paper Source setting is changed to the %s.");
/* LUM_IDD_PAG_PAGESET_NT4_AUTODUP_IDC_CHK_DUPLEX */
gchar *s = N_("Automatic Duplex Printing");
/* LUM_AlertMessTitlePaperNotAvailableForAutoDuplex_M */
gchar *s = N_("A page size that is not supported by \n"
              "the duplex printing function is selected.");
/* LUM_AlertMessPaperNotAvailableForAutoDuplex */
gchar *s = N_("Uncheck %s.");
/* LUM_MODIFY_IDD_PAG_MAIN_IDC_STT_PAPERFEED */
gchar *s = N_("Paper Source");
/* LUM_MessPSNotCasette_M */
gchar *s = N_("A page size that cannot be fed from the cassette was selected.");
/* LUM_AlertMessPaperNotFedFromCassetteOrFront */
gchar *s = N_("Change the %s setting to %s.");
/* media_supply_change_mes */
gchar *s = N_("Paper Source: %s is not available for the selected Media Type.\n"
              "Paper Source setting has been changed to %s.");
/* bkenh_enh */
gchar *s = N_("Enhanced Black");
/* size_a5 */
gchar *s = N_("A5 [5.83\"x8.27\" 148.0x210.0mm]");
/* size_a4 */
gchar *s = N_("A4 [8.27\"x11.69\" 210.0x297.0mm]");
/* size_a3 */
gchar *s = N_("A3 [11.69\"x16.54\" 297.0x420.0mm]");
/* size_b5 */
gchar *s = N_("B5 [7.17\"x10.12\" 182.0x257.0mm]");
/* size_b4 */
gchar *s = N_("B4 [10.12\"x14.33\" 257.0x364.0mm]");
/* size_letter */
gchar *s = N_("Letter [8.50\"x11.00\" 215.9x279.4mm]");
/* size_legal */
gchar *s = N_("Legal [8.50\"x14.00\" 215.9x355.6mm]");
/* size_ledger */
gchar *s = N_("11\"x17\" [11.00\"x17.00\" 279.4x431.8mm]");
/* size_csize */
gchar *s = N_("17\"x22\" 431.8x558.8mm");
/* size_post */
gchar *s = N_("Hagaki [3.94\"x5.83\" 100.0x148.0mm]");
/* size_env_10 */
gchar *s = N_("Comm. Env. #10 9.5\"x4.12\" 241.3x104.8mm");
/* size_env_dl */
gchar *s = N_("DL Env. 220.0x110.0mm");
/* size_fools */
gchar *s = N_("13.5\"x17\" 342.9x431.8mm");
/* size_env_j4 */
gchar *s = N_("Youkei 4 235.0x105.0mm");
/* size_env_j6 */
gchar *s = N_("Youkei 6 190.0x98.0mm");
/* size_letter_bleed */
gchar *s = N_("Letter+ 9\"x13.3\" 228.6x337.8mm");
/* size_a4_bleed */
gchar *s = N_("A4+ 223.5x355.6mm");
/* size_a3_plus */
gchar *s = N_("A3+ [12.95\"x19.02\" 329.0x483.0mm]");
/* size_photocard */
gchar *s = N_("Canon 4\"x6\" 101.6x152.4mm");
/* size_user */
gchar *s = N_("Custom...");
/* size_env_10_p */
gchar *s = N_("Comm. Env. #10 [4.12\"x9.50\" 104.8x241.3mm]");
/* size_env_dl_p */
gchar *s = N_("DL Env. [4.33\"x8.66\" 110.0x220.0mm]");
/* size_env_j4_p */
gchar *s = N_("Youkei 4 [4.13\"x9.25\" 105.0x235.0mm]");
/* size_env_j6_p */
gchar *s = N_("Youkei 6 [3.86\"x7.48\" 98.0x190.0mm]");
/* size_l */
gchar *s = N_("L [3.50\"x5.00\" 89.0x127.0mm]");
/* size_2l */
gchar *s = N_("2L [5.00\"x7.01\" 127.0x178.0mm]");
/* size_4x6 */
gchar *s = N_("4\"x6\" [4.00\"x6.00\" 101.6x152.4mm]");
/* size_panorama */
gchar *s = N_("P 89.0x254.0mm");
/* size_5x7 */
gchar *s = N_("5\"x7\" [5.00\"x7.00\" 127.0x177.8mm]");
/* size_post_dbl */
gchar *s = N_("Hagaki 2 [7.87\"x5.83\" 200.0x148.0mm]");
/* size_businesscard */
gchar *s = N_("Card [2.16\"x3.58\" 55.0x91.0mm]");
/* size_creditcard */
gchar *s = N_("Credit Card 2.13\"x3.39\" 54.0x86.0mm");
/* size_letter_fine_art */
gchar *s = N_("Fine Art Letter [8.50\"x11.00\" 215.9x279.4mm]");
/* size_a4_fine_art */
gchar *s = N_("Fine Art A4 [8.27\"x11.69\" 210.0x297.0mm]");
/* size_4X8 */
gchar *s = N_("4\"x8\" [4.00\"x8.00\" 101.6x203.2mm]");
/* size_4giri */
gchar *s = N_("10\"x12\" [10.00\"x12.00\" 254.0x304.8mm]");
/* size_6giri */
gchar *s = N_("8\"x10\" [8.00\"x10.00\" 203.2x254.0mm]");
/* size_wide */
gchar *s = N_("Wide [4.00\"x7.11\" 101.6x180.6mm]");
/* custom_size_mm_format */
gchar *s = N_("mm (%s-%s)");
/* custom_size_inches_format */
gchar *s = N_("inches (%s-%s)");
/* tmessage_position1 */
gchar *s = N_("Position 1");
/* tmessage_position2 */
gchar *s = N_("Position 2");
/* tmessage_position3 */
gchar *s = N_("Position 3");
/* tmessage_left */
gchar *s = N_("Left");
/* tmessage_center */
gchar *s = N_("Center");
/* tmessage_right */
gchar *s = N_("Right");
/* tmessage_lower */
gchar *s = N_("Down");
/* tmessage_upper */
gchar *s = N_("Up");
/* tmessage_lower2 */
gchar *s = N_("Down");
/* tmessage_upper2 */
gchar *s = N_("Up");
/* tmessage_left2 */
gchar *s = N_("Left");
/* tmessage_right2 */
gchar *s = N_("Right");
/* plmessage_foward */
gchar *s = N_("Front");
/* plmessage_backword */
gchar *s = N_("Back");
/* plmessage_lower */
gchar *s = N_("Down");
/* plmessage_upper */
gchar *s = N_("Up");
/* slmess_smooth */
gchar *s = N_("Smoothing");
/* bin_pattern */
gchar *s = N_("Fine");
/* bin_pattern_hs */
gchar *s = N_("Fine(Fast)");
/* banner_on */
gchar *s = N_("Banner Printing");
/* cartridge_color */
gchar *s = N_("Color    ");
/* cartridge_bk */
gchar *s = N_("Black    ");
/* cartridge_photo */
gchar *s = N_("Photo    ");
/* cartridge_bk_color */
gchar *s = N_("Black/Color    ");
/* cartridge_bk_photo */
gchar *s = N_("Black/Photo    ");
/* cartridge_photo_color */
gchar *s = N_("Photo/Color    ");
/* printing_type_fit */
gchar *s = N_("Fit-to-Page");
/* printing_type_normal */
gchar *s = N_("Normal-size");
/* printing_type_scale */
gchar *s = N_("Scaled");
/* input_gamma_default */
gchar *s = N_("Default");
/* input_gamma_10 */
gchar *s = N_("More bright (Gamma = 1.0)");
/* input_gamma_14 */
gchar *s = N_("Light");
/* input_gamma_18 */
gchar *s = N_("Normal");
/* input_gamma_22 */
gchar *s = N_("Dark");
/* paper_gap_auto */
gchar *s = N_("Auto");
/* paper_gap_wide */
gchar *s = N_("Wide");
/* paper_gap_narrow */
gchar *s = N_("Narrow");
/* LUM_IDS_EDGETOEDGE_SELECTED */
gchar *s = N_("You have selected Borderless Printing.\n"
              "The document to be printed is enlarged, so that it slightly extends off the paper.\n"
              "Print quality may deteriorate, or the sheet may be stained at the top and bottom \n"
              "depending on the type of media used.");
/* mediaborder_dialog_message1 */
gchar *s = N_("Borderless printing is not recommended when %s is selected for Media Type.\n"
              "Select the type of media you wish to use.");
/* LUM_IDD_MEDIA_CHANGE_ETOE_IDC_STT_MEDIA_NOTE_ETOE */
gchar *s = N_("The document to be printed is enlarged, so that it slightly extends off the paper.\n"
              "Print quality may deteriorate, or the sheet may be stained at the top and bottom \n"
              "depending on the type of media used.");
/* LUM_IDS_SMMSG_ENVELOPE_SHORTEN_ASF */
gchar *s = N_("The printer is set to print on an envelope.\n"
              "Lower the paper support and then load an envelope.\n"
              "Then click OK to start printing.");
/* message_button_ok */
gchar *s = N_("OK");
/* message_button_cancel */
gchar *s = N_("Cancel");
/* message_button_yes */
gchar *s = N_("Yes");
/* message_button_no */
gchar *s = N_("No");
/* message_button_abort */
gchar *s = N_("Abort");
/* message_button_ignore */
gchar *s = N_("Ignore");
/* autopower_enable */
gchar *s = N_("Enable");
/* autopower_disable */
gchar *s = N_("Disable");
/* autopower_5min */
gchar *s = N_("5 minutes");
/* autopower_10min */
gchar *s = N_("10 minutes");
/* autopower_15min */
gchar *s = N_("15 minutes");
/* autopower_30min */
gchar *s = N_("30 minutes");
/* autopower_60min */
gchar *s = N_("60 minutes");
/* utility_message_3 */
gchar *s = N_("Were the patterns printed normally?\n"
              "\n"
              "If no patterns were printed or if the printout is noticeably blurred, click No and start again from the beginning.");
/* utility_message_4 */
gchar *s = N_("Make sure that the printer power is on, the cable is connected properly, and the printer is online then try again.");
/* utility_message_5 */
gchar *s = N_("Print head alignment is now complete.");
/* utility_message_6 */
gchar *s = N_("Do not start another operation until the current one has finished.");
/* utility_message_8 */
gchar *s = N_("Turn the printer off?");
/* utility_message_9 */
gchar *s = N_("Apply settings to printer?");
/* utility_message_12 */
gchar *s = N_("Start print head deep cleaning?");
/* regi_bidir */
gchar *s = N_("Bi-directional Alignment (-5 to +5)");
/* utility_message_23 */
gchar *s = N_("Execute black print head deep cleaning?");
/* utility_message_24 */
gchar *s = N_("Execute color print head deep cleaning?");
/* utility_message_27 */
gchar *s = N_("Cleaning paper feed rollers.\n"
              "\n"
              "First remove paper from the sheet feeder. Clicking OK will activate paper feed rollers 30 times. \n"
              "This will take about a minute and a half. When you load three sheets of plain paper according to \n"
              "the message, paper will be ejected and feed roller cleaning will be completed.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* utility_message_28 */
gchar *s = N_("Load three sheets of plain paper into the sheet feeder.\n");
/* LUM_IDS_MNTMSG_ROLLCLEAN_I320_3 */
gchar *s = N_("Feed roller cleaning is complete.");
/* util_ink_all_1 */
gchar *s = N_("All Colors");
/* LUM_IDS_CLEAN_ITEM_ALL_KCMY */
gchar *s = N_("All Colors   BK, C, M, Y");
/* util_ink_black_0 */
gchar *s = N_("Black");
/* util_ink_black_1 */
gchar *s = N_("Black   3eBK");
/* util_ink_black_2 */
gchar *s = N_("Black   PGBK");
/* LUM_IDS_CLEAN_ITEM_H1 */
gchar *s = N_("Black   BK");
/* util_ink_color_0 */
gchar *s = N_("Color");
/* util_ink_color_1 */
gchar *s = N_("Color   6C, 6M, 6Y");
/* util_ink_color_2 */
gchar *s = N_("Color   6C, 6M, 6Y, 6BK");
/* util_ink_color_3 */
gchar *s = N_("Color   7C, 7M, 7Y");
/* util_ink_color_4 */
gchar *s = N_("Color   7C, 7M, 7Y, 7BK");
/* util_ink_color_5 */
gchar *s = N_("Color   C, M, Y, BK");
/* util_ink_color_6 */
gchar *s = N_("Color   C, M, Y, PC, PM, BK");
/* LUM_IDS_CLEAN_ITEM_E4 */
gchar *s = N_("Color   C, M, Y");
/* util_ink_gr1_1 */
gchar *s = N_("Group 1   6BK, 6R, 6PC, 6PM");
/* util_ink_gr1_2 */
gchar *s = N_("Group 1   7BK, 7R, 7G, 7PC, 7PM");
/* util_ink_gr2_1 */
gchar *s = N_("Group 2   6C, 6M, 6Y");
/* util_ink_gr2_2 */
gchar *s = N_("Group 2   7C, 7M, 7Y");
/* LUM_IDS_MNTMSG_UNTILFINISH_CLEANING */
gchar *s = N_("Do not start another operation until the cleaning has finished.\n"
              "\n"
              "After cleaning ends, execute nozzle check to check whether the print head nozzles have been unclogged.");
/* LUM_IDS_CLEAN_TOPIC_EX */
gchar *s = N_("Cleans clogged print head nozzles.\n"
              "\n"
              "Select the target ink group for cleaning. If you are not sure of the ink group \n"
              "for cleaning, execute nozzle check.");
/* LUM_IDS_CLEAN_TOPIC_DEEP_EX */
gchar *s = N_("Unclogs nozzles that cannot be cleared by regular cleaning.\n"
              "\n"
              "Select the target ink group for deep cleaning. If you are not sure of the ink \n"
              "group for deep cleaning, execute nozzle check.");
/* utility_message_41 */
gchar *s = N_("Ink Group:");
/* LUM_IDS_CLEAN_PS_DEEP_EX */
gchar *s = N_("Deep cleaning consumes much more ink than regular cleaning. Execute deep \n"
              "cleaning only if the nozzle condition does not improve after regular cleaning.\n"
              "\n"
              "After the deep cleaning ends, execute nozzle check and check whether \n"
              "the print head nozzles have been unclogged.");
/* utility_message_43 */
gchar *s = N_("Cleaning consumes ink.");
/* utility_message_44 */
gchar *s = N_("Load a sheet of A4 or letter size paper into the paper source selected by the Paper Feed Switch and click OK.\n");
/* LUM_IDS_MNTMSG_PC_NG2 */
gchar *s = N_("If the printed pattern resembles this pattern, \n"
              "the print head nozzles may be clogged.\n"
              "Click Cleaning.\n"
              "\n"
              "If the printed pattern does not improve, \n"
              "even after Cleaning is executed two times, \n"
              "execute deep cleaning.");
/* utility_message_50 */
gchar *s = N_("Load a sheet of A4 or letter size paper into the sheet feeder and click OK.");
/* utility_message_53 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready(connect the cable and turn \n"
              "the power on), set the printer's paper thickness lever to the left and load a sheet of \n"
              "A4 or letter size, plain paper into the sheet feeder. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click OK.\n");
/* utility_message_54 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), set the printer's paper thickness lever to the left, \n"
              "load a sheet of A4 or letter size, plain paper into the sheet feeder, and click the Print Check Pattern.\n");
/* util_ink_cartridge_1 */
gchar *s = N_("Color Only");
/* util_ink_cartridge_2 */
gchar *s = N_("Black Only");
/* util_ink_cartridge_3 */
gchar *s = N_("Both Black and Color");
/* utility_message_55 */
gchar *s = N_("Prints using only color cartridge instead of \n"
              "black cartridge.");
/* utility_message_56 */
gchar *s = N_("Prints using only black cartridge instead of \n"
              "color cartridge only when Plain Paper is \n"
              "selected for the Media Type on the Main Tab.");
/* utility_message_57 */
gchar *s = N_("Prints using both black and color cartridges.");
/* LUM_IDS_MNTMSG_UNTILFINISH_NUMBER_1 */
gchar *s = N_("The printer will print one sheet of pattern to start alignment automatically.\n"
              "Do not start another operation until the current one has finished.");
/* utility_message_60 */
gchar *s = N_("Second sheet of head alignment pattern will be printed.\n"
              "\n"
              "Click OK to start printing.");
/* utility_message_61 */
gchar *s = N_("Third sheet of head alignment pattern will be printed.\n"
              "\n"
              "Click OK to start printing.");
/* LUM_IDS_MNTMSG_PHA_START1_LEFT_2BIN */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the left and load a sheet of A4 or letter size, plain paper \n"
              "into the paper source selected by the Paper Feed Switch. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* utility_message_63 */
gchar *s = N_("Print head alignment is complete.\n"
              "To finish the alignment, click Cancel.\n"
              "\n"
              "If streaks appear on the printing side, you can prevent them from appearing by aligning the print head.\n"
              "To execute this alignment, load a sheet of paper into the sheet feeder and click OK.");
/* utility_message_64 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), set the printer's paper \n"
              "thickness lever to the left, load a sheet of A4 or letter size, plain paper into the paper \n"
              "source selected by the Paper Feed Switch, and click the Print Check Pattern.");
/* utility_message_66 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Load a sheet of A4 or letter size, plain paper into the sheet feeder and click the Print Check Pattern.");
/* utility_message_67 */
gchar *s = N_("Print head alignment is complete.\n"
              "To finish the alignment, click Cancel.\n"
              "\n"
              "If streaks appear on the printing side, \n"
              "you can prevent them from appearing by aligning the print head.\n"
              "To execute this alignment, load a sheet of paper into the paper source selected \n"
              "by the Paper Feed Switch and click OK.");
/* LUM_IDS_MNTMSG_PHA_START1_RIGHT */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the right and load a sheet of A4 or letter size, plain paper \n"
              "into the sheet feeder. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PC_NG */
gchar *s = N_("If the printed pattern resembles this pattern, \n"
              "the print head nozzles may be clogged.\n"
              "Click Cleaning.\n"
              "\n"
              "If the printed pattern does not improve, \n"
              "even after Cleaning is executed two to three times, \n"
              "execute deep cleaning.");
/* utility_message_71 */
gchar *s = N_("You cannot reset the ink counter because the printer is set to disable the display of low ink warning.\n"
              "\n"
              "To enable the display of a low ink warning, click the Low Ink Warning Setting button on \n"
              "the Maintenance tab of the printer driver.\n"
              "Read your printer manual before carrying out this operation.");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_REAR */
gchar *s = N_("Cleaning paper feed rollers.\n"
              "\n"
              "First remove paper from the rear tray.\n"
              "Clicking OK will activate paper feed rollers 30 times. This will take about a minute and a half.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_2BIN */
gchar *s = N_("Cleaning paper feed rollers.\n"
              "\n"
              "First press the Paper Feed Switch on the printer to select the target paper source for cleaning, \n"
              "and then remove paper from the selected paper source.\n"
              "Clicking OK will activate paper feed rollers 30 times. This will take about a minute and a half.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_2_REAR */
gchar *s = N_("Confirm the operating noise of the printer has stopped, and then load three sheets of plain paper into the rear tray.\n"
              "Clicking OK will eject paper and complete feed roller cleaning.");
/* LUM_IDS_MNTMSG_ROLLCLEAN_2_2BIN */
gchar *s = N_("Confirm the operating noise of the printer has stopped, and then load three sheets of plain paper into the selected paper source.\n"
              "Clicking OK will eject paper and complete feed roller cleaning.");
/* LUM_IDS_MNTMSG_PLATENCLEAN_A4 */
gchar *s = N_("1. Remove the paper from the sheet feeder.\n"
              "2. Fold A4 or letter size, plain paper in half, then unfold the paper.\n"
              "3. With the ridge of the crease facing down, load the paper into the sheet feeder.\n"
              "4. Click Execute.");
/* LUM_IDS_MNTMSG_PLATENCLEAN_A4_07 */
gchar *s = N_("1. Remove the paper from the rear tray.\n"
              "2. Fold A4 or letter size, plain paper in half, then unfold the paper.\n"
              "3. With the ridge of the crease facing down, load the paper into the rear tray.\n"
              "4. Click Execute.");
/* LUM_IDS_MNTMSG_PATTERNCHECKPRE_LEVERLEFT_07 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), set the printer's paper thickness \n"
              "lever to the left, load a sheet of A4 or letter size, plain paper into the rear tray, and click \n"
              "the Print Check Pattern.");
/* LUM_IDS_MNTMSG_PHA_START2_2P_LEFT_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the left and load two sheets of A4 or letter size, plain \n"
              "paper into the rear tray. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_START_AUTOMATIC */
gchar *s = N_("Starting automatic print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "load one sheet of A4 or letter size, plain paper into the sheet feeder and click Align Print Head. \n"
              "\n"
              "To carry out manual head alignment, click Cancel.\n"
              "Next, click Custom Settings on the Maintenance tab of the printer driver, check Align heads manually, \n"
              "and click OK. Then try again.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_START_AUTOMATIC_MP2_07 */
gchar *s = N_("Starting automatic print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "load two sheets of A4 or letter size, Matte Photo Paper (MP-101) into the rear tray and click \n"
              "Align Print Head. \n"
              "\n"
              "To carry out manual head alignment, click Cancel.\n"
              "Next, click Custom Settings on the Maintenance tab of the printer driver, check Align heads manually, \n"
              "and click OK. Then try again.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_CHKPHA_2BIN_ASF_PLAIN_07 */
gchar *s = N_("Load one sheet of A4 or letter size, plain paper into the rear tray and click OK.");
/* LUM_IDS_MNTMSG_UNTILFINISH_NUMBER_2 */
gchar *s = N_("The printer will print two sheets of pattern to start alignment automatically.\n"
              "Do not start another operation until the current one has finished.");
/* LUM_IDS_MNTMSG_PHA_START2_4P_2BIN */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) \n"
              "and load four sheets of A4 or letter size, plain paper into the paper source selected by the Paper \n"
              "Feed Switch. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_NEXT4P_2BIN */
gchar *s = N_("Fourth sheet of head alignment pattern will be printed.\n"
              "\n"
              "Click OK to start printing.");
/* LUM_IDS_MNTMSG_PATTERNCHECKPRE_2BIN */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Load a sheet of A4 or letter size, plain paper into the paper source selected by the Paper Feed Switch \n"
              "and click the Print Check Pattern.");
/* LUM_IDS_MNTMSG_PHA_START1_LEFT_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the left and load a sheet of A4 or letter size, plain paper \n"
              "into the rear tray. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_START2_2BIN */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) \n"
              "and load a sheet of A4 or letter size, plain paper into the paper source selected by the Paper \n"
              "Feed Switch. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_CHKPHA_2BIN_ASF_07 */
gchar *s = N_("Load a sheet of A4 or letter size paper into the rear tray and click OK.");
/* LUM_IDS_MNTMSG_PHA_NEXT_DETAILCANCEL_07 */
gchar *s = N_("Print head alignment is complete.\n"
              "To finish the alignment, click Cancel.\n"
              "\n"
              "If streaks appear on the printing side, you can prevent them from appearing by aligning the print head.\n"
              "To execute this alignment, load a sheet of paper into the rear tray and click OK.");
/* LUM_IDS_MNTMSG_PHA_START2_3P_2BIN */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) \n"
              "and load three sheets of A4 or letter size, plain paper into the paper source selected by the Paper \n"
              "Feed Switch. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_START1_LEFT */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the left and load a sheet of A4 or letter size, plain paper \n"
              "into the sheet feeder. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PATTERNCHECKPRE_LEVERRIGHT_07 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), set the printer's paper thickness lever to the right, \n"
              "load a sheet of A4 or letter size, plain paper into the rear tray, and click the Print Check Pattern.");
/* LUM_IDS_CARTRIDGE_EXP_BK_2 */
gchar *s = N_("Prints using only black cartridge instead of color cartridge only when Plain Paper, \n"
              "Hagaki, or Envelope is selected for the Media Type on the Main Tab.");
/* LUM_IDS_MNTMSG_PHA_START_LEVERLEFT_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready(connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the left and load a sheet of A4 or letter size, plain paper into the rear tray. \n"
              "The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click OK.");
/* LUM_IDS_MNTMSG_PHA_START2_2P_RIGHT_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the right and load two sheets of A4 or letter size, plain paper \n"
              "into the rear tray. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_START_AUTOMATIC_MP1_LEVERRIGHT_07 */
gchar *s = N_("Starting automatic print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "set the printer's paper thickness lever to the right, load one sheet of A4 or letter size, Matte Photo Paper (MP-101) \n"
              "into the rear tray and click Align Print Head. \n"
              "\n"
              "To carry out manual head alignment, click Cancel.\n"
              "Next, click Custom Settings on the Maintenance tab of the printer driver, check Align heads manually, and click OK. \n"
              "Then try again.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PLATENCLEAN_A4_07_2P */
gchar *s = N_("1. Remove the paper from the rear tray, and then load the first sheet of A4 or letter size, plain paper.\n"
              "2. Fold the second sheet of A4 or letter size, plain paper in half, and then unfold the paper.\n"
              "3. With the ridge of the crease facing down, load the second sheet in front of the first sheet.\n"
              "4. Click Execute.");
/* LUM_IDS_MNTMSG_PLATENCLEAN_TOPIC_2P */
gchar *s = N_("Starting bottom plate cleaning to prevent paper smudges during printing.\n"
              "\n"
              "This operation requires two sheets of A4 or letter size, plain paper. Follow these directions to execute bottom plate cleaning.");
/* LUM_IDS_MNTMSG_PPSOURCE */
gchar *s = N_("Sets the paper source for plain paper when Automatically Select is selected for Paper Source.\n"
              "\n"
              "Select the paper source for plain paper, and then click OK.");
/* LUM_IDS_CLEAN_TOPIC_DEEP_EX_3 */
gchar *s = N_("Unclogs nozzles that cannot be cleared by regular cleaning.\n"
              "\n"
              "Select the target ink group for deep cleaning. If only the black nozzle is clogged, select Black. \n"
              "If only the color nozzles or both the black and color nozzles are clogged, select All Colors. \n"
              "If you are not sure which nozzle is clogged, execute nozzle check.\n");
/* LUM_IDS_MNTMSG_ROLLCLEAN_SELECTBIN */
gchar *s = N_("Cleaning paper feed rollers.\n"
              "\n"
              "Select the target paper source for cleaning, and then click OK.");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_REAR3 */
gchar *s = N_("Cleaning paper feed rollers for the rear tray.\n"
              "\n"
              "First remove paper from the rear tray, and then open the paper output tray.\n"
              "Clicking OK will activate paper feed rollers. This will take about a minute and a half.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_FRONT3 */
gchar *s = N_("Cleaning paper feed rollers for the cassette.\n"
              "\n"
              "First remove paper from the cassette, and then open the paper output tray.\n"
              "Clicking OK will activate paper feed rollers. This will take about two minutes.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_REAR4 */
gchar *s = N_("Cleaning paper feed rollers for the rear tray.\n"
              "\n"
              "First remove paper from the rear tray.\n"
              "Clicking OK will activate paper feed rollers. This will take about a minute and a half.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_FRONT4 */
gchar *s = N_("Cleaning paper feed rollers for the cassette.\n"
              "\n"
              "First remove paper from the cassette.\n"
              "Clicking OK will activate paper feed rollers. This will take about two minutes.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_2_FRONT2 */
gchar *s = N_("Confirm the operating noise of the printer has stopped, and then load three sheets of plain paper into the cassette.\n"
              "Clicking OK will eject paper and complete feed roller cleaning.");
/* LUM_IDS_MNTMSG_NOZZLECHECK_SELECTBIN */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "First select the paper source to be used. Then load one sheet of A4 or letter size, \n"
              "plain paper into the selected paper source and click the Print Check Pattern.");
/* LUM_IDS_MNTMSG_PATTERNCHECKPRE_CASSETTE_07 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), load one sheet of A4 or letter size, \n"
              "plain paper into the cassette, and click the Print Check Pattern.");
/* LUM_IDS_MNTMSG_PATTERNCHECKPRE_07 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), load one sheet of A4 or letter size, \n"
              "plain paper into the rear tray, and click the Print Check Pattern.");
/* LUM_IDS_MNTMSG_PHA_START2_2P_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) and \n"
              "load two sheets of A4 or letter size, plain paper into the rear tray. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_PHA_START_SELECT_UPPER */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "The alignment involves printing. Select the paper source to be used, and then click Align Print Head.");
/* LUM_IDS_PHA_START_SELECT_LOWER */
gchar *s = N_("To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_3_BINSELECT_ASF */
gchar *s = N_("Get the printer ready (connect the cable and turn the power on) and load three sheets of A4 or letter size, \n"
              "plain paper into the rear tray.\n"
              "\n"
              "Clicking OK will print an alignment pattern.");
/* LUM_IDS_MNTMSG_PHA_3_BINSELECT_FSF */
gchar *s = N_("Get the printer ready (connect the cable and turn the power on) and load three sheets of A4 or letter size, \n"
              "plain paper into the cassette.\n"
              "\n"
              "Clicking OK will print an alignment pattern.");
/* LUM_IDS_MNTMSG_PHA_CHKPHA_EXPLAIN_ASF */
gchar *s = N_("Get the printer ready (connect the cable and turn the power on) and load one sheet of A4 or letter size, \n"
              "plain paper into the rear tray.\n"
              "\n"
              "Clicking OK will print the current setting.");
/* LUM_IDS_MNTMSG_PHA_CHKPHA_EXPLAIN_FSF */
gchar *s = N_("Get the printer ready (connect the cable and turn the power on) and load one sheet of A4 or letter size, \n"
              "plain paper into the cassette.\n"
              "\n"
              "Clicking OK will print the current setting.");
/* LUM_IDS_MNTMSG_SELECTBIN_SIMPLE */
gchar *s = N_("Select the paper source to be used, and then click OK.");
/* LUM_IDS_MNTMSG_PHA_CHKPHA_2BIN_CASSETTE */
gchar *s = N_("Load one sheet of A4 or letter size, plain paper into the cassette and click OK.");
/* LUM_IDS_MNTMSG_PHA_START_AUTOMATIC_MP1_07 */
gchar *s = N_("Starting automatic print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "load one sheet of A4 or letter size, Matte Photo Paper (MP-101) into the rear tray and click Align Print Head. \n"
              "\n"
              "To carry out manual head alignment, click Cancel.\n"
              "Next, click Custom Settings on the Maintenance tab of the printer driver, check Align heads manually, \n"
              "and click OK. Then try again.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_LID_WARNING_PAPER_ABRASION */
gchar *s = N_("Sets Prevent paper abrasion. If you print with this setting enabled, the print quality or print speed may be affected. \n"
              "To change the setting, uncheck Prevent paper abrasion.");
/* LUM_IDS_CLEAN_TOPIC_DEEP_EX_2 */
gchar *s = N_("Unclogs nozzles that cannot be cleared by regular cleaning.\n"
              "\n"
              "Deep cleaning consumes much more ink than regular cleaning. Execute deep \n"
              "cleaning only if the nozzle condition does not improve after regular cleaning.\n"
              "\n"
              "After the deep cleaning ends, execute nozzle check and check whether \n"
              "the print head nozzles have been unclogged.");
/* LUM_IDS_MNTMSG_UNTILFINISH_DEEPCLEANING */
gchar *s = N_("Do not start another operation until the deep cleaning has finished.\n"
              "\n"
              "After deep cleaning ends, execute nozzle check to check whether \n"
              "the print head nozzles have been unclogged.");
/* LUM_IDS_MNTMSG_PHA_GUIDE_FROD */
gchar *s = N_("Executing print head alignment corrects the misalignment of colors and lines. \n"
              "Refer to the user's guide, and align the print head from the printer's operation panel.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_MNTMSG_PHA_START2_3P_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) and \n"
              "load three sheets of A4 or letter size, plain paper into the rear tray. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.\n");
/* LUM_IDS_MNTMSG_PHA_START_AUTOMATIC_MP1_09 */
gchar *s = N_("Starting automatic print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "load one sheet of A4 or letter size, Matte Photo Paper (MP-101) into the rear tray and click Align Print Head. \n"
              "\n"
              "If the results of automatic print head alignment are not satisfactory, perform manual print head alignment to \n"
              "precisely align the print head.\n"
              "To carry out manual head alignment, click Cancel.\n"
              "Next, click Custom Settings on the Maintenance tab of the printer driver, check Align heads manually, \n"
              "and click OK. Then try again.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_CARTRIDGE_EXP_BK_3 */
gchar *s = N_("Prints using only black cartridge instead of color cartridge only when Plain Paper, Hagaki A, \n"
              "Hagaki, or Envelope is selected for the Media Type on the Main Tab.");
/* LUM_IDS_MNTMSG_PHA_START2_3P_07 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) and \n"
              "load three sheets of A4 or letter size, plain paper into the rear tray. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.\n");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_BLACK_LABEL */
gchar *s = N_("  Black:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_CYAN_LABEL */
gchar *s = N_("Cyan:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_MAGENTA_LABEL */
gchar *s = N_("Magenta:");
/* LUM_IDD_PAG_MAIN_IDC_BTN_QUALITY */
gchar *s = N_("  Set...  ");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_YELLOW_LABEL */
gchar *s = N_("Yellow:");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_SCALING_RANGE */
gchar *s = N_("% (20-400)");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_COPIES_RANGE */
gchar *s = N_("(1-999)");
/*  */
gchar *s = N_("BJF850");
/*  */
gchar *s = N_("BJF850");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_5 */
gchar *s = N_("1");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_4 */
gchar *s = N_("2");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_3 */
gchar *s = N_("3");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_2 */
gchar *s = N_("4");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_1 */
gchar *s = N_("5");
/* LUM_IDR_PV_MAIN_IDM_PV_VERSION */
gchar *s = N_("About");
/* LUM_IDD_PHA_A3430_1_IDC_STT_PHA_H1_LABEL */
gchar *s = N_("Adjustment in Columns A to C (-3 to +7)");
/* LUM_IDS_MNTMSG_PHA_CPT_A_D_37 */
gchar *s = N_("Adjustment in Columns A to D (-3 to +7)");
/* LUM_IDD_PHA_A2630_1_IDC_STT_PHA_H1_LABEL */
gchar *s = N_("Adjustment in Columns A to E (-3 to +7)");
/* LUM_IDS_MNTMSG_PHA_CPT_A_E_55 */
gchar *s = N_("Adjustment in Columns A to E (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_A_F_55 */
gchar *s = N_("Adjustment in Columns A to F (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_A_G_55 */
gchar *s = N_("Adjustment in Columns A to G (-5 to +5)");
/* LUM_IDD_PHA_A3430_1_IDC_STT_PHA_B1_LABEL */
gchar *s = N_("Adjustment in Columns D to F (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_E_G_55 */
gchar *s = N_("Adjustment in Columns E to G (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_F_G_33 */
gchar *s = N_("Adjustment in Columns F and G (-3 to +3)");
/* LUM_IDD_PHA_A2630_1_IDC_STT_PHA_B1_LABEL */
gchar *s = N_("Adjustment in Columns F to K (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_G_J_55 */
gchar *s = N_("Adjustment in Columns G to J (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_G_L_55 */
gchar *s = N_("Adjustment in Columns G to L (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_H_K_55 */
gchar *s = N_("Adjustment in Columns H to K (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_H_L_55 */
gchar *s = N_("Adjustment in Columns H to L (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_H_N_55 */
gchar *s = N_("Adjustment in Columns H to N (-5 to +5)");
/* LUM_IDD_PHA_A3430_2_IDC_STT_PHA_V1_LABEL */
gchar *s = N_("Adjustment in Columns K and L (-3 to +3)");
/* LUM_IDD_PHA_A2630_2_IDC_STT_PHA_V1_LABEL */
gchar *s = N_("Adjustment in Columns L and M (-3 to +3)");
/* LUM_IDS_MNTMSG_PHA_CPT_L_O_55 */
gchar *s = N_("Adjustment in Columns L to O (-5 to +5)");
/* LUM_IDD_PHA_A3430_3_IDC_STT_PHA_H1_LABEL */
gchar *s = N_("Adjustment in Columns M and N (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_M_P_22 */
gchar *s = N_("Adjustment in Columns M to P (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_M_Q_55 */
gchar *s = N_("Adjustment in Columns M to Q (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_O_T_22 */
gchar *s = N_("Adjustment in Columns O to T (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_P_T_55 */
gchar *s = N_("Adjustment in Columns P to T (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_Q_R_44 */
gchar *s = N_("Adjustment in Columns Q and R (-4 to +4)");
/* LUM_IDS_MNTMSG_PHA_CPT_U_V_22 */
gchar *s = N_("Adjustment in Columns U and V (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_U_V_33 */
gchar *s = N_("Adjustment in Columns U and V (-3 to +3)");
/* LUM_IDS_MNTMSG_PHA_CPT_W_X_33 */
gchar *s = N_("Adjustment in Columns W and X (-3 to +3)");
/* LUM_IDS_MNTMSG_PHA_CPT_a_e_22 */
gchar *s = N_("Adjustment in Columns a to e (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_f_j_22 */
gchar *s = N_("Adjustment in Columns f to j (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_f_k_22 */
gchar *s = N_("Adjustment in Columns f to k (-2 to +2)");
/* LUM_IDD_PHA_START_IDOK */
gchar *s = N_("Align Print Head");
/* LUM_IDS_CUSTOM_CPT_MANUALPHA */
gchar *s = N_("Align heads manually");
/* LUM_IDS_CLEAN_ITEM_ALL */
gchar *s = N_("All Colors");
/* LUM_IDD_PAG_PAGESET_XP_ETOE_IDC_STT_ETOEOVERPRINT */
gchar *s = N_("Amount of Extension:");
/* LUM_IDD_PAG_MAIN_IDC_RAD_COLORADJ_AUTO */
gchar *s = N_("Auto");
/* LUM_IDS_MNT_CPT_AUTOPOWER */
gchar *s = N_("Auto Power");
/* LUM_IDD_AUTOPOWER2_OFFONLY_IDC_STT_AUTOPOWER_OFF */
gchar *s = N_("Auto Power Off");
/* LUM_IDD_AUTOPOWER_IDC_STT_AUTOPOWER_OFF */
gchar *s = N_("Auto Power Off:");
/* LUM_IDD_AUTOPOWER_IDC_STT_AUTOPOWER_ON */
gchar *s = N_("Auto Power On:");
/* LUM_IDD_AUTOPOWER */
gchar *s = N_("Auto Power Settings");
/* LUM_IDS_PT_DN_AUTODUPLEX */
gchar *s = N_("Automatic Duplex Printing");
/* LUM_IDD_MEDIA_CHANGE_ETOE_IDC_STT_MEDIA_TITLE_ETOE */
gchar *s = N_("Available Media Types:");
/* LUM_IDD_PAG_MAIN_IDC_STT_CARTRIDGE */
gchar *s = N_("BJ Cartridge:");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDCANCEL */
gchar *s = N_("Back to Setup");
/* LUM_IDD_PHA_I850_1_IDC_STT_PHA_B1_LABEL */
gchar *s = N_("Bi-directional Alignment (-5 to +5)");
/* LUM_IDS_CLEAN_ITEM_BLACK */
gchar *s = N_("Black");
/* LUM_IDD_INKCOUNT_IDC_CHK_INKCOUNT_BLACK */
gchar *s = N_("Black Ink Tank");
/* LUM_IDS_EDGETOEDGE */
gchar *s = N_("Borderless");
/* LUM_IDS_MNT_CPT_PLATENCLEAN */
gchar *s = N_("Bottom Plate Cleaning");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_BRIGHTNESS */
gchar *s = N_("Brightness:");
/* LUM_IDD_MESSAGEBOX_IDCANCEL */
gchar *s = N_("Cancel");
/*  */
gchar *s = N_("BJF850");
/* LUM_IDS_CASSETTE */
gchar *s = N_("Cassette");
/* LUM_LID_CENTERRING */
gchar *s = N_("Centering");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDOK */
gchar *s = N_("Change");
/* LUM_LID_CHANGE_COMBINATION */
gchar *s = N_("Change Combination");
/* LUM_LID_CHANGE_MEDIA */
gchar *s = N_("Change Media Type");
/* LUM_IDS_MNT_CPT_CLEAN */
gchar *s = N_("Cleaning");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDC_STT_SA_RESOLV2S */
gchar *s = N_("Click Change to use this, or Back to Setup to select a different combination.");
/* LUM_IDS_COLLATE */
gchar *s = N_("Collate");
/* LUM_IDS_CLEAN_ITEM_COLOR */
gchar *s = N_("Color");
/* LUM_LID_COLOR_BALANCE */
gchar *s = N_("Color Balance");
/* LUM_IDD_INKCOUNT_IDC_CHK_INKCOUNT_COLOR */
gchar *s = N_("Color Ink Tank");
/* LUM_IDD_MANUALCOLOR_MATCHING_IDC_STT_COLORMODE */
gchar *s = N_("Color Mode:");
/* LUM_IDS_COLORADJUSTMENT */
gchar *s = N_("Color/Intensity");
/* LUM_IDS_MNTMSG_PHA_ITEM_A */
gchar *s = N_("Column A:");
/* LUM_IDS_MNTMSG_PHA_ITEM_B */
gchar *s = N_("Column B:");
/* LUM_IDS_MNTMSG_PHA_ITEM_C */
gchar *s = N_("Column C:");
/* LUM_IDS_MNTMSG_PHA_ITEM_D */
gchar *s = N_("Column D:");
/* LUM_IDS_MNTMSG_PHA_ITEM_E */
gchar *s = N_("Column E:");
/* LUM_IDS_MNTMSG_PHA_ITEM_F */
gchar *s = N_("Column F:");
/* LUM_IDS_MNTMSG_PHA_ITEM_G */
gchar *s = N_("Column G:");
/* LUM_IDS_MNTMSG_PHA_ITEM_H */
gchar *s = N_("Column H:");
/* LUM_IDS_MNTMSG_PHA_ITEM_I */
gchar *s = N_("Column I:");
/* LUM_IDS_MNTMSG_PHA_ITEM_J */
gchar *s = N_("Column J:");
/* LUM_IDS_MNTMSG_PHA_ITEM_K */
gchar *s = N_("Column K:");
/* LUM_IDS_MNTMSG_PHA_ITEM_L */
gchar *s = N_("Column L:");
/* LUM_IDS_MNTMSG_PHA_ITEM_M */
gchar *s = N_("Column M:");
/* LUM_IDS_MNTMSG_PHA_ITEM_N */
gchar *s = N_("Column N:");
/* LUM_IDS_MNTMSG_PHA_ITEM_O */
gchar *s = N_("Column O:");
/* LUM_IDS_MNTMSG_PHA_ITEM_P */
gchar *s = N_("Column P:");
/* LUM_IDS_MNTMSG_PHA_ITEM_Q */
gchar *s = N_("Column Q:");
/* LUM_IDS_MNTMSG_PHA_ITEM_R */
gchar *s = N_("Column R:");
/* LUM_IDS_MNTMSG_PHA_ITEM_S */
gchar *s = N_("Column S:");
/* LUM_IDS_MNTMSG_PHA_ITEM_T */
gchar *s = N_("Column T:");
/* LUM_IDS_MNTMSG_PHA_ITEM_U */
gchar *s = N_("Column U:");
/* LUM_IDS_MNTMSG_PHA_ITEM_V */
gchar *s = N_("Column V:");
/* LUM_IDS_MNTMSG_PHA_ITEM_W */
gchar *s = N_("Column W:");
/* LUM_IDS_MNTMSG_PHA_ITEM_X */
gchar *s = N_("Column X:");
/* LUM_IDS_MNTMSG_PHA_ITEM_a */
gchar *s = N_("Column a:");
/* LUM_IDS_MNTMSG_PHA_ITEM_b */
gchar *s = N_("Column b:");
/* LUM_IDS_MNTMSG_PHA_ITEM_c */
gchar *s = N_("Column c:");
/* LUM_IDS_MNTMSG_PHA_ITEM_d */
gchar *s = N_("Column d:");
/* LUM_IDS_MNTMSG_PHA_ITEM_e */
gchar *s = N_("Column e:");
/* LUM_IDS_MNTMSG_PHA_ITEM_f */
gchar *s = N_("Column f:");
/* LUM_IDS_MNTMSG_PHA_ITEM_g */
gchar *s = N_("Column g:");
/* LUM_IDS_MNTMSG_PHA_ITEM_h */
gchar *s = N_("Column h:");
/* LUM_IDS_MNTMSG_PHA_ITEM_i */
gchar *s = N_("Column i:");
/* LUM_IDS_MNTMSG_PHA_ITEM_j */
gchar *s = N_("Column j:");
/* LUM_IDS_MNTMSG_PHA_ITEM_k */
gchar *s = N_("Column k:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_COLORCONTRAST_LABEL */
gchar *s = N_("Contrast:");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_COPIES */
gchar *s = N_("Copies:");
/* LUM_IDD_PAG_MAIN_IDC_RAD_QUALITY_CUSTOM */
gchar *s = N_("Custom");
/* LUM_IDD_PAPER_CUSTOM */
gchar *s = N_("Custom Paper Size");
/* LUM_IDS_MNT_CPT_CUSTOM */
gchar *s = N_("Custom Settings");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_CYAN_LABEL */
gchar *s = N_("Cyan:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_INTENSITY_HI */
gchar *s = N_("Dark ");
/* LUM_IDS_MNT_CPT_DEEPCLEAN */
gchar *s = N_("Deep Cleaning");
/* LUM_IDD_PAG_MAIN_IDC_BTN_MAIN_DEFAULT */
gchar *s = N_("Defaults");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_HALFTONE_DIFFUSION */
gchar *s = N_("Diffusion");
/* LUM_IDD_INKALERT_IDC_CHK_INKALERT_ENABLE */
gchar *s = N_("Display low ink warning");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_HALFTONE_DITHERING */
gchar *s = N_("Dither");
/* LUM_IDD_PHA_A3430_2_IDC_STT_PHA_TEXT */
gchar *s = N_("Examine the printed patterns, and enter the pattern number \n"
              "of the pattern with the least noticeable streaks in the fields \n"
              "for columns G to L.");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_H_O */
gchar *s = N_("Examine the printed patterns, and enter the pattern number \n"
              "of the pattern with the least noticeable streaks in the fields \n"
              "for columns H to O.");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_M_R */
gchar *s = N_("Examine the printed patterns, and enter the pattern number \n"
              "of the pattern with the least noticeable streaks in the fields \n"
              "for columns M to R.");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_P_V */
gchar *s = N_("Examine the printed patterns, and enter the pattern number \n"
              "of the pattern with the least noticeable streaks in the fields \n"
              "for columns P to V.");
/* LUM_IDS_MNTMSG_PHA_TOPIC3_O_V */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable horizontal stripes in the fields \n"
              "for columns O to V.");
/* LUM_IDD_PHA_A3430_3_IDC_STT_PHA_TEXT */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of the most \n"
              "even pattern for columns M and N.");
/* LUM_IDS_MNTMSG_PHA_TOPIC3_a_j */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
              "with the least noticeable horizontal stripes in the fields for columns a to j.");
/* LUM_IDS_MNTMSG_PHA_TOPIC3_a_k */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
              "with the least noticeable horizontal stripes in the fields for columns a to k.");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_H_Q */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of the pattern \n"
              "with the least noticeable streaks in the fields for columns H to Q.");
/* LUM_IDD_PHA_A2630_2_IDC_STT_PHA_TEXT */
gchar *s = N_("Examine the printed patterns, and fill in the fields for columns \n"
              "L and M with the number of the pattern that is smoothest and \n"
              "has no stripes in the areas indicated by arrows.");
/* LUM_IDS_MNTMSG_PHA_TOPIC5_W_X */
gchar *s = N_("Examine the printed patterns, and fill in the fields for columns W \n"
              "and X with the number of the pattern that is smoothest and has \n"
              "no stripes in the areas indicated by arrows.");
/* LUM_IDD_BITMAPMESSAGE_IDOK */
gchar *s = N_("Execute");
/* LUM_IDS_MNTMSG_PHA_TOPIC1_A_F */
gchar *s = N_("Execute print head alignment. Examine the printed patterns, \n"
              "and enter the pattern number of the pattern with the least \n"
              "noticeable streaks in the fields for columns A to F.");
/* LUM_IDS_MNTMSG_PHA_TOPIC1_A_G */
gchar *s = N_("Execute print head alignment. Examine the printed patterns, \n"
              "and enter the pattern number of the pattern with the least \n"
              "noticeable streaks in the fields for columns A to G.");
/* LUM_IDS_MNTMSG_PHA_TOPIC1_A_K */
gchar *s = N_("Execute print head alignment. Examine the printed patterns, \n"
              "and enter the pattern number of the pattern with the least \n"
              "noticeable streaks in the fields for columns A to K.");
/* LUM_IDS_MNTMSG_PHA_TOPIC1_A_L */
gchar *s = N_("Execute print head alignment. Examine the printed patterns, \n"
              "and enter the pattern number of the pattern with the least \n"
              "noticeable streaks in the fields for columns A to L.");
/* LUM_IDS_MNTMSG_PHA_TOPIC1_A_N */
gchar *s = N_("Execute print head alignment. Examine the printed patterns, \n"
              "and enter the pattern number of the pattern with the least \n"
              "noticeable streaks in the fields for columns A to N.");
/* LUM_IDD_PATTERNCHECK_EX_IDOK */
gchar *s = N_("Exit");
/* LUM_IDS_QUALITY_FAST */
gchar *s = N_("Fast");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_FAST */
gchar *s = N_("Fast ");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_FINE */
gchar *s = N_("Fine");
/* LUM_IDD_PAG_MAIN_IDC_CHK_GRAYSCALE */
gchar *s = N_("Grayscale Printing");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_HALFTONE */
gchar *s = N_("Halftoning");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_HEIGHT_LABEL */
gchar *s = N_("Height:     ");
/* LUM_IDS_QUALITY_BEST */
gchar *s = N_("High");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_COLORCONTRAST_HI */
gchar *s = N_("High ");
/* LUM_IDD_PHA_I850_1_IDC_STT_PHA_H1_LABEL */
gchar *s = N_("Horizontal Alignment (-3 to +7)");
/* LUM_IDD_SA_RECOMMENDCOMBINATIONONE_IDIGNORE */
gchar *s = N_("Ignore");
/* LUM_IDS_MNT_CPT_CARTRIDGE */
gchar *s = N_("Ink Cartridge Settings");
/* LUM_IDS_SELECTCHD_TITLE */
gchar *s = N_("Ink Cartridge:");
/* LUM_IDS_MNT_CPT_INKCOUNT */
gchar *s = N_("Ink Counter Reset");
/* LUM_IDD_CUSTOM_IDC_STT_INKDRY */
gchar *s = N_("Ink Drying Wait Time:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_INTENSITY_LABEL */
gchar *s = N_("Intensity:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_INTENSITY_LO */
gchar *s = N_("Light ");
/* LUM_IDD_CUSTOM_IDC_STT_INKDRY_DRYNESS */
gchar *s = N_("Long");
/* LUM_IDS_STAPLE_LONGSIDE */
gchar *s = N_("Long-side stapling");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_COLORCONTRAST_LO */
gchar *s = N_("Low");
/* LUM_IDS_MNT_CPT_INKALERT */
gchar *s = N_("Low Ink Warning Setting");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_MAGENTA_LABEL */
gchar *s = N_("Magenta:");
/* LUM_IDD_PAG_MAIN */
gchar *s = N_("Main");
/* LUM_IDD_PAG_MAINTENANCE */
gchar *s = N_("Maintenance");
/* LUM_IDD_PAG_MAIN_IDC_RAD_COLORADJ_MANUAL */
gchar *s = N_("Manual");
/* LUM_IDS_MANUALCOLOR_WINDOWTITLE */
gchar *s = N_("Manual Color Adjustment");
/* LUM_LID_MAX */
gchar *s = N_("Max");
/* LUM_IDD_PAG_MAIN_IDC_STT_MEDIATYPE */
gchar *s = N_("Media Type:");
/* LUM_LID_MIN */
gchar *s = N_("Min");
/* LUM_IDS_MNT_CPT_NOZZLE */
gchar *s = N_("Nozzle Check");
/* LUM_IDD_MESSAGEBOX_IDOK */
gchar *s = N_("OK");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_PRINTTYPE */
gchar *s = N_("Page Layout:");
/* LUM_IDD_PAG_PAGESET_XP */
gchar *s = N_("Page Setup");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_PAGESIZE */
gchar *s = N_("Page Size:");
/* LUM_LID_PAPER_GAP */
gchar *s = N_("Paper Gap:");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_PAPERSIZE */
gchar *s = N_("Paper Size");
/* LUM_IDS_MNT_CPT_PPSOURCE */
gchar *s = N_("Paper Source Setting for Plain Paper");
/* LUM_IDD_PAG_MAIN_IDC_STT_PAPERFEED */
gchar *s = N_("Paper Source:");
/* LUM_IDD_PATTERNCHECK_EX */
gchar *s = N_("Pattern Check");
/* LUM_IDS_CUSTOM_CPT_PAUSEPAGE */
gchar *s = N_("Pause Page");
/* LUM_IDS_CUSTOM_CPT_PAUSESCAN */
gchar *s = N_("Pause Scan");
/* LUM_IDS_MNT_CPT_POWEROFF */
gchar *s = N_("Power Off");
/* LUM_IDS_CUSTOM_CPT_PAPERGAP */
gchar *s = N_("Prevent paper abrasion");
/* LUM_IDD_PHA_START_IDC_BTN_CHKPHA */
gchar *s = N_("Print Alignment Value");
/* LUM_IDD_PATTERNCHECK_START_IDOK */
gchar *s = N_("Print Check Pattern");
/* LUM_IDS_MNT_CPT_PHA */
gchar *s = N_("Print Head Alignment");
/* LUM_IDD_CLEAN */
gchar *s = N_("Print Head Cleaning");
/* LUM_IDD_PAG_MAIN_IDC_GRP_QUALITY */
gchar *s = N_("Print Quality");
/* LUM_LID_PRINT_TYPE */
gchar *s = N_("Print Type:");
/* LUM_IDD_PAG_PAGESET_XP_IDC_CHK_REVERSE */
gchar *s = N_("Print from Last Page");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_LABEL */
gchar *s = N_("Quality");
/* LUM_IDD_SILENTMODE */
gchar *s = N_("Quiet Mode");
/* LUM_IDD_INKALERT_IDC_STT_INKALERT_1 */
gchar *s = N_("Read your printer manual for details about low ink warnings.");
/* LUM_IDS_FEED_REAR */
gchar *s = N_("Rear Tray");
/* LUM_IDS_MNT_CPT_ROLLCLEAN */
gchar *s = N_("Roller Cleaning");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_SCALING */
gchar *s = N_("Scaling:");
/* LUM_IDS_MNTMSG_CARTRIDGE_TOPIC */
gchar *s = N_("Select the ink cartridge for printing.");
/* LUM_IDD_INKCOUNT_IDC_STT_INKCOUNT_1 */
gchar *s = N_("Select the newly replaced ink tank and click the Execute button.\n");
/* LUM_IDD_GENERAL_RAD_2_IDOK */
gchar *s = N_("Send");
/* LUM_IDD_CUSTOM_IDC_STT_INKDRY_SPEEDY */
gchar *s = N_("Short");
/* LUM_IDS_STAPLE_SHORTSIDE */
gchar *s = N_("Short-side stapling");
/* LUM_IDS_OUTPUTSTYLE_STANDARD */
gchar *s = N_("Standard");
/* LUM_IDD_PAG_PAGESET_XP_MANUDUP_IDC_STT_EDGE */
gchar *s = N_("Staple Side:");
/* LUM_IDD_PHA_START */
gchar *s = N_("Start Print Head Alignment");
/* LUM_IDS_MNTMSG_PLATENCLEAN_TOPIC */
gchar *s = N_("Starting bottom plate cleaning to prevent paper smudges during printing.\n"
              "\n"
              "This operation requires one sheet of A4 or letter size, plain paper. Follow these directions to execute bottom plate cleaning.");
/* LUM_IDD_INKCOUNT_IDC_STT_INKCOUNT_2 */
gchar *s = N_("The counter corresponding to the replaced ink tank will indicate \n"
              "the tank is full. This operation ensures proper display of a low \n"
              "ink warning.");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDC_STT_SA_TITLE2 */
gchar *s = N_("The following is recommended:");
/* LUM_IDS_MNTMSG_PC_OK */
gchar *s = N_("The print head nozzles are not clogged.\n"
              "If the printed pattern resembles this pattern, you can \n"
              "use the printer immediately.\n"
              "Click Exit.");
/* LUM_IDD_INKALERT_IDC_STT_INKALERT_2 */
gchar *s = N_("To ensure proper display of a low ink warning, the following operation is \n"
              "required:\n");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_UNITS */
gchar *s = N_("Units:");
/* LUM_IDD_SILENTMODE_EX_IDC_CHK_QUIET */
gchar *s = N_("Use quiet mode");
/* LUM_IDD_AUTOPOWER2_OFFONLY_IDC_STT_AUTOPOWER_OFF_AC */
gchar *s = N_("Using AC Adapter:");
/* LUM_IDD_AUTOPOWER2_OFFONLY_IDC_STT_AUTOPOWER_OFF_BATTERY */
gchar *s = N_("Using Battery:");
/* LUM_IDD_PAG_MAINTENANCE_IDC_BTN_STATUSMONITOR */
gchar *s = N_("View Printer Status...");
/* LUM_IDD_PAG_EFFECT_VIVID_IDC_CHK_VIVID */
gchar *s = N_("Vivid Photo");
/* LUM_IDD_INKALERT_IDC_STT_INKALERT_3 */
gchar *s = N_("When you have replaced an ink tank with a new one, always click \n"
              "the Ink Counter Reset button on the Maintenance tab of the printer driver \n"
              "and select the new ink tank.");
/* LUM_IDS_MNTMSG_PC_TOPIC */
gchar *s = N_("Which of the following patterns does the printed pattern most closely resemble?");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_WIDTH_LABEL */
gchar *s = N_("Width:    ");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_YELLOW_LABEL */
gchar *s = N_("Yellow:");
/* LUM_IDD_SA_INVALIDCOMBINATION_IDC_STT_SA_TITLE */
gchar *s = N_("You cannot print with the following combination:");
/* LUM_IDD_SA_RECOMMENDCOMBINATIONONE_IDC_STT_SA_TITLE */
gchar *s = N_("You have selected the following combination:");
/* LUM_IDD_PAPER_CUSTOM_IDC_RAD_INCH */
gchar *s = N_("inch");
/* LUM_IDD_PAPER_CUSTOM_IDC_RAD_MM */
gchar *s = N_("mm");
/* LUM_IDS_MNTMSG_PHA_CPT_K_P_55 */
gchar *s = N_("Adjustment in Columns K to P (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_CPT_F_33 */
gchar *s = N_("Adjustment in Column F (-3 to +3)");
/* LUM_IDS_MNTMSG_PHA_CPT_G_33 */
gchar *s = N_("Adjustment in Column G (-3 to +3)");
/* LUM_IDS_MNTMSG_PHA_CPT_Q_44 */
gchar *s = N_("Adjustment in Column Q (-4 to +4)");
/* LUM_IDS_MNTMSG_PHA_CPT_R_U_22 */
gchar *s = N_("Adjustment in Columns R to U (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_V_Y_22 */
gchar *s = N_("Adjustment in Columns V to Y (-2 to +2)");
/* LUM_IDD_PHA_GUIDE_IDCANCEL */
gchar *s = N_("Close");
/* LUM_IDS_MNTMSG_PHA_ITEM_Y */
gchar *s = N_("Column Y:");
/* LUM_IDS_MNTMSG_PHA_TOPIC3_Q_Y */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable horizontal stripes in \n"
              "the fields for columns Q to Y.");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_K_P */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable streaks in the fields for \n"
              "columns K to P.");
/* LUM_IDS_MNTMSG_PHA_TOPIC1_A_J */
gchar *s = N_("Execute print head alignment. Examine the printed patterns, \n"
              "and enter the pattern number of the pattern with the least \n"
              "noticeable streaks in the fields for columns A to J.");
/* LUM_IDS_MNT_CPT_CUSTOM */
gchar *s = N_("Custom Settings");
/* LUM_IDS_CUSTOM_CPT_PAPERGAP */
gchar *s = N_("Prevent paper abrasion");
/* LUM_IDS_CUSTOM_CPT_MANUALPHA */
gchar *s = N_("Align heads manually");
/* LUM_IDD_CUSTOM_IDC_STT_INKDRY */
gchar *s = N_("Ink Drying Wait Time:");
/* LUM_IDD_CUSTOM_IDC_STT_INKDRY_SPEEDY */
gchar *s = N_("Short");
/* LUM_IDD_CUSTOM_IDC_STT_INKDRY_DRYNESS */
gchar *s = N_("Long");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_5 */
gchar *s = N_("1");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_4 */
gchar *s = N_("2");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_3 */
gchar *s = N_("3");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_2 */
gchar *s = N_("4");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_1 */
gchar *s = N_("5");
/* LUM_IDD_GENERAL_RAD_2_IDOK */
gchar *s = N_("Send");
/* LUM_IDS_CLEAN_ITEM_E5 */
gchar *s = N_("Color   C, M, Y, BK, GY");
/* LUM_IDS_MNTMSG_PLATENCLEAN_A3_07 */
gchar *s = N_("1. Remove the paper from the rear tray.\n"
              "2. Fold A4 or letter size, plain paper in half vertically, then unfold the paper.\n"
              "3. With the ridge of the crease facing down, load the paper in landscape orientation into the rear tray.\n"
              "4. Click Execute.");
/* LUM_IDS_AUTOPOWER_120MINUTES */
gchar *s = N_("120 minutes");
/* LUM_IDS_AUTOPOWER_240MINUTES */
gchar *s = N_("240 minutes");
/* LUM_IDS_MNTMSG_PHA_START_AUTOMATIC_11_PAPERSRC */
gchar *s = N_("Starting automatic print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on), \n"
              "load one sheet of A4 or letter size plain paper, and click Align Print Head.\n"
              "\n"
              "If the results of automatic print head alignment are not satisfactory, perform manual print head alignment to precisely align the print head.\n"
              "To carry out manual head alignment, click Cancel.\n"
              "Next, click Custom Settings on the Maintenance tab of the printer driver, check Align heads manually, and click OK. Then try again.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDS_CUSTOM_CPT_PREVENTPAPERJAM */
gchar *s = N_("Prevent paper jam");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_REAR7 */
gchar *s = N_("Cleaning paper feed rollers.\n"
              "\n"
              "First remove paper from the rear tray, then open the front cover and extend the paper output tray.\n"
              "Clicking OK will activate paper feed rollers 30 times. This will take about a minute and a half.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_H_P */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable streaks in the fields for columns H to P.");
/* LUM_IDS_MNTMSG_PHA_CPT_M_P_55 */
gchar *s = N_("Adjustment in Columns M to P (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_TOPIC3_a_i */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable horizontal stripes in the fields for columns a to i.");
/* LUM_IDS_MNTMSG_PHA_CPT_f_i_22 */
gchar *s = N_("Adjustment in Columns f to i (-2 to +2)");
/* LUM_IDS_MNTMSG_PREVENTPAPERGAP_MSG */
gchar *s = N_("Set Prevent paper jam only when A3 size plain paper jams frequently near the paper output slot.\n"
              "\n"
              "This setting increases the printing time for A3 size plain paper.\n"
              "Also, the print quality may deteriorate.");
/* supply_cassette_06 */
gchar *s = N_("Front Tray");
/* LUM_IDD_QUIETSETTINGS */
gchar *s = N_("Quiet Settings");
/* LUM_IDD_QUIETSETTINGS_IDC_RAD_QUIETSETTINGS_DISABLE */
gchar *s = N_("Do not use quiet mode");
/* LUM_IDD_QUIETSETTINGS_IDC_RAD_QUIETSETTINGS_ENABLE */
gchar *s = N_("Always use quiet mode");
/* LUM_IDD_QUIETSETTINGS_IDC_RAD_QUIETSETTINGS_HOURS */
gchar *s = N_("Use quiet mode during specified hours");
/* LUM_IDD_QUIETSETTINGS_IDC_STT_QUIETSETTINGS_FROM */
gchar *s = N_("Start time:");
/* LUM_IDD_QUIETSETTINGS_IDC_STT_QUIETSETTINGS_TO */
gchar *s = N_("End time:");
/* LUM_IDD_QUIETSETTINGS_IDC_STT_QUIETSETTING_WARN */
gchar *s = N_("When the hours are specified, quiet mode is not applied to operations \n"
              "(copy, direct print, etc.) performed directly from the printer.");
/* LUM_COLON */
gchar *s = N_(":");
/* LUM_IDS_MNTMSG_WRITESETTING_ATPOFF_NW */
gchar *s = N_("Apply the setting to printer?\n"
              "If the printer is connected to a network, it will not turn off \n"
              "automatically even if Auto Power Off is set.");
/* LUM_IDS_MNTMSG_ROLLCLEAN_1_FRONT7 */
gchar *s = N_("Cleaning paper feed rollers.\n"
              "\n"
              "First remove paper from the front tray, then open the paper output tray.\n"
              "Clicking OK will activate paper feed rollers. This will take about two minutes to complete.\n"
              "\n"
              "Do you want to start feed roller cleaning?");
/* LUM_IDS_MNTMSG_ROLLCLEAN_2_FRONT7 */
gchar *s = N_("Confirm the operating noise of the printer has stopped, and then load three sheets of plain paper into the front tray.\n"
              "After confirming that the paper output tray is open, clicking OK will eject paper and complete feed roller cleaning.");
/* LUM_IDS_MNTMSG_PLATENCLEAN_A4_FRONT */
gchar *s = N_("1. Remove the paper from the front tray.\n"
              "2. Fold A4 or letter size, plain paper in half, then unfold the paper.\n"
              "3. Fold one side of the paper in another half, aligning the edge with the center crease, then unfold the paper.\n"
              "4. With the ridges of the creases facing up, load the paper into the front tray, \n"
              "so that the edge of the half with no crease faces away from you.\n"
              "5. Open the paper output tray and click Execute.");
/* LUM_IDS_CUSTOM_CPT_PREVENTWFEED */
gchar *s = N_("Prevent paper double-feed");
/* LUM_IDS_MNTMSG_PREVENTWFEED_MSG */
gchar *s = N_("Set Prevent paper double-feed only when double-feeding of plain paper occurs.\n"
              "\n"
              "Using this function decreases the print speed but reduces the occurrence of double-feeding.");
/* LUM_IDS_MNTMSG_PATTERNCHECKPRE_PAPERSRC_11 */
gchar *s = N_("Prints a pattern that lets you check whether the print head nozzles are clogged.\n"
              "\n"
              "Get the printer ready (connect the cable and turn the power on), load one sheet of A4 \n"
              "or letter size plain paper, and click the Print Check Pattern.");
/* LUM_IDS_MNTMSG_PHA_START2_3P_PAPERSRC_11 */
gchar *s = N_("Starting print head alignment.\n"
              "\n"
              "Since the alignment involves printing, get the printer ready (connect the cable and turn the power on) \n"
              "and load three sheets of A4 or letter size, plain paper. The printer will print an alignment pattern.\n"
              "\n"
              "To align the print head position, click Align Print Head.\n"
              "\n"
              "To print and check the current setting, click Print Alignment Value.");
/* LUM_IDD_PAG_PAGESET_XP_MANUDUP_AUTODUP_IDC_CHK_DUPLEX */
gchar *s = N_("Duplex Printing");
/* LUM_MessTitlePaperLoadGuide */
gchar *s = N_("Check how to load paper.");
/* LUM_MessContentsPaperLoadGuide */
gchar *s = N_("Fit the paper into the front tray so that the printing side faces down.\n"
              "Insert the paper completely to the end of the front tray.\n"
              "\n"
              "Click [OK] to start printing.");
/* LUM_IDS_MNTMSG_PHA_CPT_G_K_55 */
gchar *s = N_("Adjustment in Columns G to K (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_TOPIC2_L_Q */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable streaks in the fields for \n"
              "columns L to Q.");
/* LUM_IDS_MNTMSG_PHA_TOPIC3_R_Z */
gchar *s = N_("Examine the printed patterns, and enter the pattern number of \n"
              "the pattern with the least noticeable horizontal stripes in the fields for \n"
              "columns R to Z.");
/* LUM_IDS_MNTMSG_PHA_CPT_R_44 */
gchar *s = N_("Adjustment in Column R (-4 to +4)");
/* LUM_IDS_MNTMSG_PHA_CPT_S_V_22 */
gchar *s = N_("Adjustment in Columns S to V (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_W_Z_22 */
gchar *s = N_("Adjustment in Columns W to Z (-2 to +2)");
/* LUM_IDS_MNTMSG_PHA_CPT_L_Q_55 */
gchar *s = N_("Adjustment in Columns L to Q (-5 to +5)");
/* LUM_IDS_MNTMSG_PHA_ITEM_Z */
gchar *s = N_("Column Z:");
