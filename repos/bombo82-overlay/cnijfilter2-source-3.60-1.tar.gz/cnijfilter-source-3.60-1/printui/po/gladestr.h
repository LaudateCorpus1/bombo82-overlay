/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_BLACK_LABEL */
char *s = N_("  Black:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_CYAN_LABEL */
char *s = N_("  Cyan:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_MAGENTA_LABEL */
char *s = N_("  Magenta:");
/* LUM_IDD_PAG_MAIN_IDC_BTN_QUALITY */
char *s = N_("  Set...  ");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_YELLOW_LABEL */
char *s = N_("  Yellow:");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_SCALING_RANGE */
/* xgettext:no-c-format */
char *s = N_("% (20-400)");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_COPIES_RANGE */
char *s = N_("(1-999)");
char *s = N_("*");
char *s = N_("0");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_5 */
char *s = N_("1");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_4 */
char *s = N_("2");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_3 */
char *s = N_("3");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_2 */
char *s = N_("4");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_1 */
char *s = N_("5");
char *s = N_(":");
/* LUM_IDR_PV_MAIN_IDM_PV_VERSION */
char *s = N_("About");
/* LUM_IDD_PAG_PAGESET_XP_ETOE_IDC_STT_ETOEOVERPRINT */
char *s = N_("Amount of Extension:");
/* LUM_IDD_PAG_MAIN_IDC_RAD_COLORADJ_AUTO */
char *s = N_("Auto");
/* LUM_IDS_MNT_CPT_AUTOPOWER */
char *s = N_("Auto Power");
/* LUM_IDD_MEDIA_CHANGE_ETOE_IDC_STT_MEDIA_TITLE_ETOE */
char *s = N_("Available Media Types:");
/* LUM_IDD_PAG_MAIN_IDC_STT_CARTRIDGE */
char *s = N_("BJ Cartridge:");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDCANCEL */
char *s = N_("Back to Setup");
/* LUM_IDS_EDGETOEDGE */
char *s = N_("Borderless");
/* LUM_IDS_MNT_CPT_PLATENCLEAN */
char *s = N_("Bottom Plate Cleaning");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_BRIGHTNESS */
char *s = N_("Brightness:");
/* LUM_IDD_MESSAGEBOX_IDCANCEL */
char *s = N_("Cancel");
/* LUM_LID_CENTERRING */
char *s = N_("Centering");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDOK */
char *s = N_("Change");
/* LUM_LID_CHANGE_COMBINATION */
char *s = N_("Change Combination");
/* LUM_LID_CHANGE_MEDIA */
char *s = N_("Change Media Type");
/* LUM_IDS_MNT_CPT_CLEAN */
char *s = N_("Cleaning");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDC_STT_SA_RESOLV2S */
char *s = N_("Click Change to use this, or Back to Setup to select a different combination.");
/* LUM_IDS_COLLATE */
char *s = N_("Collate");
/* LUM_LID_COLOR_BALANCE */
char *s = N_("Color Balance");
/* LUM_IDD_MANUALCOLOR_MATCHING_IDC_STT_COLORMODE */
char *s = N_("Color Mode:");
/* LUM_IDS_COLORADJUSTMENT */
char *s = N_("Color/Intensity");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_COLORCONTRAST_LABEL */
char *s = N_("Contrast:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_TONE_LO */
char *s = N_("Cool");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_COPIES */
char *s = N_("Copies:");
/* LUM_IDD_PAG_MAIN_IDC_RAD_QUALITY_CUSTOM */
char *s = N_("Custom");
/* LUM_IDD_PAPER_CUSTOM */
char *s = N_("Custom Paper Size");
/* LUM_IDS_MNT_CPT_CUSTOM */
char *s = N_("Custom Settings");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_CYAN_LABEL */
char *s = N_("Cyan:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_INTENSITY_HI */
char *s = N_("Dark ");
/* LUM_IDS_MNT_CPT_DEEPCLEAN */
char *s = N_("Deep Cleaning");
/* LUM_IDD_PAG_MAIN_IDC_BTN_MAIN_DEFAULT */
char *s = N_("Defaults");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_HALFTONE_DIFFUSION */
char *s = N_("Diffusion");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_HALFTONE_DITHERING */
char *s = N_("Dither");
/* LUM_IDD_PAG_PAGESET_XP_MANUDUP_AUTODUP_IDC_CHK_DUPLEX */
char *s = N_("Duplex Printing");
/* LUM_IDS_QUALITY_FAST */
char *s = N_("Fast");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_FAST */
char *s = N_("Fast ");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_FINE */
char *s = N_("Fine");
/* LUM_IDD_PAG_MAIN_IDC_CHK_GRAYSCALE */
char *s = N_("Grayscale Printing");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_HALFTONE */
char *s = N_("Halftoning");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_HEIGHT_LABEL */
char *s = N_("Height:     ");
/* LUM_IDS_QUALITY_BEST */
char *s = N_("High");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_COLORCONTRAST_HI */
char *s = N_("High ");
/* LUM_IDD_SA_RECOMMENDCOMBINATIONONE_IDIGNORE */
char *s = N_("Ignore");
/* LUM_IDS_MNT_CPT_CARTRIDGE */
char *s = N_("Ink Cartridge Settings");
/* LUM_IDS_MNT_CPT_INKCOUNT */
char *s = N_("Ink Counter Reset");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_INTENSITY_LABEL */
char *s = N_("Intensity:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_INTENSITY_LO */
char *s = N_("Light ");
/* LUM_IDS_STAPLE_LONGSIDE */
char *s = N_("Long-side stapling");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_COLORCONTRAST_LO */
char *s = N_("Low");
/* LUM_IDS_MNT_CPT_INKALERT */
char *s = N_("Low Ink Warning Setting");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_MAGENTA_LABEL */
char *s = N_("Magenta:");
/* LUM_IDD_PAG_MAIN */
char *s = N_("Main");
/* LUM_IDD_PAG_MAINTENANCE */
char *s = N_("Maintenance");
/* LUM_IDD_PAG_MAIN_IDC_RAD_COLORADJ_MANUAL */
char *s = N_("Manual");
/* LUM_IDS_MANUALCOLOR_WINDOWTITLE */
char *s = N_("Manual Color Adjustment");
/* LUM_LID_MAX */
char *s = N_("Max");
/* LUM_IDD_PAG_MAIN_IDC_STT_MEDIATYPE */
char *s = N_("Media Type:");
/* LUM_LID_MIN */
char *s = N_("Min");
/* LUM_IDS_MNT_CPT_NOZZLE */
char *s = N_("Nozzle Check");
/* LUM_IDD_MESSAGEBOX_IDOK */
char *s = N_("OK");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_PRINTTYPE */
char *s = N_("Page Layout:");
/* LUM_IDD_PAG_PAGESET_XP */
char *s = N_("Page Setup");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_PAGESIZE */
char *s = N_("Page Size:");
/* LUM_LID_PAPER_GAP */
char *s = N_("Paper Gap:");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_PAPERSIZE */
char *s = N_("Paper Size");
/* LUM_IDS_MNT_CPT_PPSOURCE */
char *s = N_("Paper Source Setting for Plain Paper");
/* LUM_IDD_PAG_MAIN_IDC_STT_PAPERFEED */
char *s = N_("Paper Source:");
/* LUM_IDS_MNT_CPT_POWEROFF */
char *s = N_("Power Off");
/* LUM_IDS_MNT_CPT_PHA */
char *s = N_("Print Head Alignment");
/* LUM_IDD_PAG_MAIN_IDC_GRP_QUALITY */
char *s = N_("Print Quality");
/* LUM_LID_PRINT_TYPE */
char *s = N_("Print Type:");
/* LUM_IDD_PAG_PAGESET_XP_IDC_CHK_REVERSE */
char *s = N_("Print from Last Page");
/* LUM_IDD_CUSTOMQUALITY_IDC_STT_CUSTOMQUALITY_LABEL */
char *s = N_("Quality");
/* LUM_IDD_QUIETSETTINGS */
char *s = N_("Quiet Settings");
/* LUM_IDS_MNT_CPT_ROLLCLEAN */
char *s = N_("Roller Cleaning");
/* LUM_IDD_PAG_PAGESET_XP_IDC_STT_SCALING */
char *s = N_("Scaling:");
/* LUM_IDS_STAPLE_SHORTSIDE */
char *s = N_("Short-side stapling");
/* LUM_IDS_OUTPUTSTYLE_STANDARD */
char *s = N_("Standard");
/* LUM_IDD_PAG_PAGESET_XP_MANUDUP_IDC_STT_EDGE */
char *s = N_("Staple Side:");
/* LUM_IDD_SA_INVALIDCOMBINATIONONE_IDC_STT_SA_TITLE2 */
char *s = N_("The following is recommended:");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_TONE_LABEL */
char *s = N_("Tone:");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_UNITS */
char *s = N_("Units:");
/* LUM_IDD_PAG_MAINTENANCE_IDC_BTN_STATUSMONITOR */
char *s = N_("View Printer Status...");
/* LUM_IDD_PAG_EFFECT_VIVID_IDC_CHK_VIVID */
char *s = N_("Vivid Photo");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_TONE_HI */
char *s = N_("Warm");
/* LUM_IDD_PAPER_CUSTOM_IDC_STT_WIDTH_LABEL */
char *s = N_("Width:    ");
/* LUM_IDD_MANUALCOLOR_COLOR_IDC_STT_YELLOW_LABEL */
char *s = N_("Yellow:");
/* LUM_IDD_SA_INVALIDCOMBINATION_IDC_STT_SA_TITLE */
char *s = N_("You cannot print with the following combination:");
/* LUM_IDD_SA_RECOMMENDCOMBINATIONONE_IDC_STT_SA_TITLE */
char *s = N_("You have selected the following combination:");
char *s = N_("dialog1");
char *s = N_("dialog3");
/* LUM_IDD_PAPER_CUSTOM_IDC_RAD_INCH */
char *s = N_("inch");
/* LUM_IDD_PAPER_CUSTOM_IDC_RAD_MM */
char *s = N_("mm");
